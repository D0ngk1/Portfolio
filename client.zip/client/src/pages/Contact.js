export default function Contact(){
    return (<h1>Contacts</h1>)
}